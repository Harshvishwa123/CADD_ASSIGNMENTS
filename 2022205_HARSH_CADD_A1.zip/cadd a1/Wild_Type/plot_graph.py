import matplotlib.pyplot as plt

# Define the profile file name (make sure it's in the same directory)
profile_file = "P25942.profile"  # Change to your actual profile filename

# Initialize lists for residues and DOPE scores
residues = []
dope_scores = []

# Read the profile file
with open(profile_file, "r") as file:
    for line in file:
        if line.startswith("#") or line.strip() == "":
            continue  # Skip comments and empty lines
        parts = line.split()
        try:
            residue_num = int(parts[0])  # Extract residue index
            dope_score = float(parts[-1])  # Extract last column (DOPE score)
            residues.append(residue_num)
            dope_scores.append(dope_score)
        except ValueError:
            continue  # Skip lines that cannot be parsed

# Plot DOPE Score vs. Residue Index
plt.figure(figsize=(8, 5))
plt.plot(residues, dope_scores, "r-", linewidth=2, label="DOPE Score Profile")  # Red line
plt.xlabel("Residue Index")
plt.ylabel("DOPE Score")
plt.title("DOPE Score vs. Residue Index")
plt.legend()
plt.grid()

# Save and show the plot
plt.savefig("dope_profile.png", dpi=300)  # Save the plot as a PNG
plt.show()
