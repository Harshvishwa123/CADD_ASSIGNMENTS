from modeller import *
from modeller.automodel import *

env = Environ()
a = AutoModel(env, alnfile='TvLDH-mult.ali',
              knowns=('6faxR','7p3iA','8yx1C'), sequence='P25942')
a.starting_model = 1
a.ending_model = 5
a.make()